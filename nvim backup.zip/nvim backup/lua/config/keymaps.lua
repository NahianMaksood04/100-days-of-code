-- Keymaps are automatically loaded on the VeryLazy event
-- Default keymaps that are always set: https://github.com/LazyVim/LazyVim/blob/main/lua/lazyvim/config/keymaps.lua
-- Add any additional keymaps here


-- keymaps.lua
local utils = require("config.utils")

vim.keymap.set("n", "<leader>lp", function()
  local paragraph = utils.lorem_paragraph(50) -- change 50 to desired word count
  vim.api.nvim_put({ paragraph }, "c", true, true)
end, { desc = "Insert Lorem Paragraph" })


vim.keymap.set("n", "<leader>lw", function()
  vim.ui.input({ prompt = "How many lorem words? " }, function(input)
    local n = tonumber(input)
    if n then
      local text = utils.lorem_paragraph(n)
      vim.api.nvim_put({ text }, "c", true, true)
    end
  end)
end, { desc = "Insert Custom Lorem Paragraph" })


