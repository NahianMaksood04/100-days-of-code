-- utils.lua
local M = {}

local lorem_words = {
  "lorem", "ipsum", "dolor", "sit", "amet", "consectetur",
  "adipiscing", "elit", "sed", "do", "eiusmod", "tempor",
  "incididunt", "ut", "labore", "et", "dolore", "magna", "aliqua"
}

-- Generate a lorem-style paragraph with N words
function M.lorem_paragraph(word_count)
  local words = {}
  for _ = 1, word_count do
    local i = math.random(1, #lorem_words)
    table.insert(words, lorem_words[i])
  end
  local text = table.concat(words, " ") .. "."
  text = text:gsub("^%l", string.upper) -- Capitalize first letter
  return text
end

return M
