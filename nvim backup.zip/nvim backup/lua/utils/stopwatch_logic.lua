vim.g.stopwatch_start_time = nil
vim.g.stopwatch_running = false
vim.g.stopwatch_elapsed_offset = 0 -- To handle pausing
vim.g.stopwatch_total_duration = 0 -- New: Total duration for countdown in seconds

-- Function to format time (handles both elapsed and remaining)
local function format_time(seconds)
  seconds = math.max(0, seconds) -- Ensure non-negative for display
  local hours = math.floor(seconds / 3600)
  local minutes = math.floor((seconds % 3600) / 60)
  local remaining_seconds = seconds % 60
  return string.format("%02d:%02d:%02d", hours, minutes, remaining_seconds)
end

-- Function to get the current stopwatch display string
function _G.get_stopwatch_display()
  if not vim.g.stopwatch_running and vim.g.stopwatch_start_time == nil and vim.g.stopwatch_elapsed_offset == 0 and vim.g.stopwatch_total_duration == 0 then
    return "" -- Don't show if not started/reset
  end

  local elapsed_seconds = vim.g.stopwatch_elapsed_offset
  if vim.g.stopwatch_running and vim.g.stopwatch_start_time then
    elapsed_seconds = elapsed_seconds + (os.time() - vim.g.stopwatch_start_time)
  end

  local display_seconds = elapsed_seconds
  if vim.g.stopwatch_total_duration > 0 then
    display_seconds = vim.g.stopwatch_total_duration - elapsed_seconds
    if display_seconds <= 0 then
      -- Timer finished
      vim.g.stopwatch_running = false
      vim.g.stopwatch_start_time = nil
      vim.g.stopwatch_elapsed_offset = 0
      vim.g.stopwatch_total_duration = 0
      if pcall(require, "nvim-notify") then
        vim.notify("Stopwatch finished!", vim.log.levels.INFO)
      else
        print("Stopwatch finished!")
      end
      return " 00:00:00"
    end
  end

  return " " .. format_time(display_seconds)
end

-- Commands
vim.api.nvim_create_user_command("StopwatchStart", function(opts)
  local duration_minutes = tonumber(opts.fargs[1]) or 0
  if duration_minutes > 0 then
    vim.g.stopwatch_total_duration = duration_minutes * 60
  else
    vim.g.stopwatch_total_duration = 0 -- Indefinite stopwatch if no duration given
  end

  if not vim.g.stopwatch_running then
    vim.g.stopwatch_start_time = os.time()
    vim.g.stopwatch_running = true
    print("Stopwatch started" .. (duration_minutes > 0 and " for " .. duration_minutes .. " minutes." or "."))
  else
    print("Stopwatch is already running.")
  end
end, { nargs = "?", complete = "customlist,get_stopwatch_durations" })

-- Custom completion for common durations
function _G.get_stopwatch_durations(arg_lead, cmd_line, cursor_pos)
  return { "25", "50", "60" } -- Common durations
end

vim.api.nvim_create_user_command("StopwatchStop", function()
  if vim.g.stopwatch_running then
    vim.g.stopwatch_elapsed_offset = vim.g.stopwatch_elapsed_offset + (os.time() - vim.g.stopwatch_start_time)
    vim.g.stopwatch_running = false
    print("Stopwatch stopped.")
  else
    print("Stopwatch is not running.")
  end
end, {})

vim.api.nvim_create_user_command("StopwatchReset", function()
  vim.g.stopwatch_start_time = nil
  vim.g.stopwatch_running = false
  vim.g.stopwatch_elapsed_offset = 0
  vim.g.stopwatch_total_duration = 0 -- Reset duration
  print("Stopwatch reset.")
end, {})