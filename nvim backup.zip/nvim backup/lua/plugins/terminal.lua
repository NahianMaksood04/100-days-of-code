-- In ~/.config/nvim/lua/plugins/terminal.lua (create this file if needed)
return {
  "akinsho/toggleterm.nvim",
  version = "*",
  opts = {
    direction = "horizontal",  -- Terminal at the bottom
    size = 15,                 -- Similar to VS Code's height
    open_mapping = [[<C-\>]],  -- VS Code-like shortcut
    start_in_insert = true,
    persist_size = true,
    shade_terminals = true,
  },
}
