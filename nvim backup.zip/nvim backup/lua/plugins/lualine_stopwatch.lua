return {
  "nvim-lualine/lualine.nvim",
  opts = function(_, opts)
    -- Ensure the stopwatch logic is loaded
    require("utils.stopwatch_logic")

    -- Insert the stopwatch component into the lualine_x section
    -- This will place it before the default clock component
    table.insert(opts.sections.lualine_x, 1, _G.get_stopwatch_display)
    return opts
  end,
}
