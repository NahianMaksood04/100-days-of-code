return {
  "LazyVim/LazyVim",
  lazy = false,
  opts = {
    options = {
      opt = {
        tabstop = 4,
        shiftwidth = 4,
        softtabstop = 4,
        expandtab = true,
      },
    },
  },
}
