return {
  "epwalsh/pomo.nvim",
  version = "*",
  dependencies = {
    "rcarriga/nvim-notify",
  },
  config = function()
    require("pomo").setup({
      -- Your options here
    })
  end,
}