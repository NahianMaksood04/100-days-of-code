
return {
  {
    "nvim-treesitter/nvim-treesitter",
    opts = function(_, opts)
      if type(opts.ensure_installed) == "table" then
        vim.list_extend(opts.ensure_installed, { "css" })
      end
      if type(opts.indent) == "table" then
        opts.indent.enable = true
      else
        opts.indent = { enable = true }
      end
    end,
  },
}
