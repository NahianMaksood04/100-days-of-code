return {
  "derektata/lorem.nvim",
  -- No specific config needed for basic usage, it provides commands and mappings
}
