return {
  "lowitea/aw-watcher.nvim",
  opts = {
    -- You can add any options here.
    -- For example, to specify a custom ActivityWatch server:
    -- aw_server = {
    --   host = "127.0.0.1",
    --   port = 5600,
    -- },
  },
}