return {
  "folke/twilight.nvim",
  event = "VimEnter",
  config = function()
    require("twilight").setup({
      -- your twilight options can go here
    })
    vim.cmd("TwilightEnable")
  end,
}
