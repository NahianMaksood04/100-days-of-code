return {
  "mfussenegger/nvim-dap",
  dependencies = {
    "rcarriga/nvim-dap-ui", -- UI for DAP
    "nvim-neotest/nvim-nio", -- Dependency for nvim-dap-ui
    "williamboman/mason.nvim", -- For installing debug adapters
    "jay-babu/mason-nvim-dap.nvim", -- Integrates mason with dap
  },
  config = function()
    local dap = require("dap")
    local dapui = require("dapui")

    dapui.setup()

    dap.listeners.after.event_initialized["dapui_config"] = function()
      dapui.open()
    end
    dap.listeners.before.event_terminated["dapui_config"] = function()
      dapui.close()
    end
    dap.listeners.before.event_exited["dapui_config"] = function()
      dapui.close()
    end

    -- Basic keymaps for debugging
    vim.keymap.set("n", "<leader>b", dap.toggle_breakpoint, { desc = "Toggle Breakpoint" })
    vim.keymap.set("n", "<leader>dr", dap.continue, { desc = "DAP Run/Continue" })
    vim.keymap.set("n", "<leader>dn", dap.step_over, { desc = "DAP Step Over" })
    vim.keymap.set("n", "<leader>di", dap.step_into, { desc = "DAP Step Into" })
    vim.keymap.set("n", "<leader>do", dap.step_out, { desc = "DAP Step Out" })
    vim.keymap.set("n", "<leader>dc", dapui.toggle, { desc = "DAP UI Toggle" })
  end,
}
