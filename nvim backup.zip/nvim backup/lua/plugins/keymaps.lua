return {
  -- LazyVim Keymaps
  {
    "LazyVim/LazyVim",
    opts = {
      -- You can add other LazyVim options here if needed
    },
    keys = {
      -- Bufferline (Tabs) navigation
      { "<C-1>", "<cmd>BufferLineGoToBuffer 1<CR>", desc = "Go to Tab 1" },
      -- You can add more for Ctrl+2, Ctrl+3, etc.
      { "<C-2>", "<cmd>BufferLineGoToBuffer 2<CR>", desc = "Go to Tab 2" },
      { "<C-3>", "<cmd>BufferLineGoToBuffer 3<CR>", desc = "Go to Tab 3" },
      { "<C-4>", "<cmd>BufferLineGoToBuffer 4<CR>", desc = "Go to Tab 4" },
      { "<C-5>", "<cmd>BufferLineGoToBuffer 5<CR>", desc = "Go to Tab 5" },
      -- And so on, up to the number of tabs you typically use.
      -- Or for more general navigation:
      { "<C-Right>", "<cmd>BufferLineCycleNext<CR>", desc = "Next Tab" },
      { "<C-Left>", "<cmd>BufferLineCyclePrev<CR>", desc = "Previous Tab" },
    },
  },
}



